# Laurux-Pos
Terminal point de vente pour Laurux
Plus de renseignements sur le site http://www.laurux.fr
