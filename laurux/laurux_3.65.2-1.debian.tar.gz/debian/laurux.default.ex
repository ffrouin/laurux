# Defaults for laurux initscript
# sourced by /etc/init.d/laurux
# installed at /etc/default/laurux by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
