?package(laurux):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="laurux" command="/usr/bin/laurux"
