# Install

Please go to [LAURUX](http://www.laurux.fr)
to get detailed information on procedure for installing
Laurux software.

