* Mon Aug 31 2009 Jacky Tripoteau <jscops@wanadoo.fr> 
- Première version Ubuntu

* Fri Jun 20 2008 Jacky Tripoteau <jscops@wanadoo.fr> 
- Gestion des Etiquettes.
- Gestion du nombre de factures

* Tue May 13 2008 Jacky Tripoteau <jscops@wanadoo.fr> 

* Thu Mar 13 2008 Jacky Tripoteau <jscops@wanadoo.fr> 
- Version initiale

