# Laurux
Laurux est un PGI français gérant la comptabilité, les points de ventes et une gestion complète.

Plus de renseignements sur le site http://www.laurux.fr

Laurux est distribué sous la licence GPL
