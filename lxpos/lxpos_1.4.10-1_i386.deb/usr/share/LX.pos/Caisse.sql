-- MySQL dump 10.13  Distrib 5.5.43, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: Caisse
-- ------------------------------------------------------
-- Server version	5.5.43-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Fiches_Acomptes`
--

DROP TABLE IF EXISTS `Fiches_Acomptes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Acomptes` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(35) DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Acomptes`
--

LOCK TABLES `Fiches_Acomptes` WRITE;
/*!40000 ALTER TABLE `Fiches_Acomptes` DISABLE KEYS */;
INSERT INTO `Fiches_Acomptes` VALUES (1,'TOTO','G','12.32','2014-12-23');
/*!40000 ALTER TABLE `Fiches_Acomptes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Art`
--

DROP TABLE IF EXISTS `Fiches_Art`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Art` (
  `art_code` varchar(15) NOT NULL,
  `art_design` varchar(50) DEFAULT NULL,
  `art_fam` varchar(5) DEFAULT NULL,
  `art_four` varchar(8) DEFAULT NULL,
  `art_cequ` varchar(15) DEFAULT NULL,
  `art_cbarre` varchar(15) DEFAULT NULL,
  `art_cfour` varchar(25) DEFAULT NULL,
  `art_pbht` double DEFAULT NULL,
  `art_tr` double DEFAULT NULL,
  `art_paht` double DEFAULT NULL,
  `art_coef` decimal(7,4) DEFAULT NULL,
  `art_pvht` double DEFAULT NULL,
  `art_tva` char(1) DEFAULT NULL,
  `art_pvttc` double DEFAULT NULL,
  `art_cdarr` varchar(4) DEFAULT NULL,
  `art_pvar` double DEFAULT NULL,
  `art_dec` varchar(1) DEFAULT NULL,
  `art_stocke` tinyint(1) DEFAULT NULL,
  `art_qte` double DEFAULT NULL,
  `art_dpa` double DEFAULT NULL,
  `art_dfour` varchar(8) DEFAULT NULL,
  `art_pmp` double DEFAULT NULL,
  `art_ddate` varchar(10) DEFAULT NULL,
  `art_com` double DEFAULT NULL,
  `art_stkdep` double DEFAULT NULL,
  `art_nbd` varchar(1) DEFAULT NULL,
  `art_design2` varchar(50) DEFAULT NULL,
  `art_ect` int(11) DEFAULT NULL,
  `art_eco` double DEFAULT NULL,
  `art_pauaht` double DEFAULT NULL,
  `art_txconv` decimal(7,4) DEFAULT NULL,
  `art_stkmin` double DEFAULT NULL,
  `art_stkmax` double DEFAULT NULL,
  `art_suspendu` tinyint(1) DEFAULT NULL,
  `art_cpp` tinyint(1) DEFAULT NULL,
  `art_copp` double DEFAULT NULL,
  `qte1` double DEFAULT NULL,
  `qte2` double DEFAULT NULL,
  `rem1` double DEFAULT NULL,
  `qte3` double DEFAULT NULL,
  `qte4` double DEFAULT NULL,
  `rem2` double DEFAULT NULL,
  `qte5` double DEFAULT NULL,
  `qte6` double DEFAULT NULL,
  `rem3` double DEFAULT NULL,
  `qte7` double DEFAULT NULL,
  `qte8` double DEFAULT NULL,
  `rem4` double DEFAULT NULL,
  `qte9` double DEFAULT NULL,
  `qte10` double DEFAULT NULL,
  `rem5` double DEFAULT NULL,
  `qte11` double DEFAULT NULL,
  `qte12` double DEFAULT NULL,
  `rem6` double DEFAULT NULL,
  `art_frais` double DEFAULT NULL,
  `art_prvt` decimal(12,3) DEFAULT NULL,
  `art_etiq` tinyint(1) DEFAULT NULL,
  `art_poids` decimal(11,3) DEFAULT NULL,
  `art_mincom` varchar(12) DEFAULT NULL,
  `art_vol` char(5) DEFAULT NULL,
  `art_poids2` decimal(11,3) DEFAULT NULL,
  `art_photo` varchar(100) DEFAULT NULL,
  `art_crst` text,
  `art_mat` tinyint(1) DEFAULT NULL,
  `art_marque` varchar(20) DEFAULT NULL,
  `art_impcar` tinyint(1) DEFAULT NULL,
  `art_casier` char(5) DEFAULT NULL,
  `art_pvcons` decimal(12,3) DEFAULT NULL,
  `art_prdcomp` tinyint(1) DEFAULT NULL,
  `art_impdetail` tinyint(1) DEFAULT NULL,
  `art_remcas1` decimal(5,2) DEFAULT NULL,
  `art_remcas2` decimal(5,2) DEFAULT NULL,
  `art_remcas3` decimal(5,2) DEFAULT NULL,
  `art_datefbt` date DEFAULT NULL,
  `art_pbfbt` decimal(12,3) DEFAULT NULL,
  `art_ddatefbt` date DEFAULT NULL,
  `art_centrale` char(2) DEFAULT NULL,
  `art_refcentrale` char(13) DEFAULT NULL,
  `art_bonus` decimal(5,2) DEFAULT NULL,
  `art_colvte` decimal(12,3) DEFAULT NULL,
  `art_pvht2` decimal(12,3) DEFAULT NULL,
  `art_cn8` char(12) DEFAULT NULL,
  `art_crpl1` char(15) DEFAULT NULL,
  `art_crpl2` char(15) DEFAULT NULL,
  `art_ect2` tinyint(1) DEFAULT NULL,
  `art_eco2` decimal(6,3) DEFAULT NULL,
  `art_depg` tinyint(4) DEFAULT NULL,
  `art_cnsg` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`art_code`),
  KEY `art_code` (`art_code`),
  KEY `art_design` (`art_design`),
  KEY `art_fam` (`art_fam`),
  KEY `art_four` (`art_four`),
  KEY `art_cequ` (`art_cequ`),
  KEY `art_cbarre` (`art_cbarre`),
  KEY `art_cfour` (`art_cfour`),
  KEY `art_refcentrale` (`art_refcentrale`),
  KEY `id_code` (`art_code`),
  KEY `id_design` (`art_design`),
  KEY `id_fam` (`art_fam`),
  KEY `id_four` (`art_four`),
  KEY `id_cequ` (`art_cequ`),
  KEY `id_cbarre` (`art_cbarre`),
  KEY `id_cfour` (`art_cfour`),
  KEY `id_refcentrale` (`art_refcentrale`),
  KEY `id_casier` (`art_casier`),
  KEY `id_code_fam_four` (`art_code`,`art_fam`,`art_four`),
  KEY `id_code_four_fam` (`art_code`,`art_four`,`art_fam`),
  KEY `id_fam_code` (`art_fam`,`art_code`),
  KEY `id_four_code` (`art_four`,`art_code`),
  KEY `id_casier_fam` (`art_casier`,`art_fam`),
  KEY `art_cn8` (`art_cn8`),
  KEY `art_cn8_2` (`art_cn8`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Art`
--

LOCK TABLES `Fiches_Art` WRITE;
/*!40000 ALTER TABLE `Fiches_Art` DISABLE KEYS */;
INSERT INTO `Fiches_Art` VALUES ('001','Produit 2.10','01','401001','','2148413200001','',10,0,10,2.2000,22,'1',22.46,'0,01',NULL,'0',0,NULL,0,NULL,10,NULL,NULL,NULL,'2','',0,NULL,10,1.0000,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,10.000,1,0.000,'0','Kg',NULL,NULL,NULL,0,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('002','Produit 5.50','02','401001','','2640636100002','',10,0,10,2.0000,20,'2',21.1,'0,01',NULL,'0',0,NULL,0,NULL,10,NULL,NULL,NULL,'2','',0,NULL,10,1.0000,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,10.000,1,0.000,'0','Kg',NULL,'','',0,'',0,'',0.000,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('003','produit 19.60','03','401001',NULL,NULL,NULL,0,0,0,1.0000,0,'3',0,'0,01',NULL,'0',0,0,0,NULL,0,NULL,NULL,0,'2',NULL,0,NULL,0,1.0000,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.000,1,0.000,'2','Kg',NULL,NULL,NULL,0,NULL,0,NULL,0.000,0,0,0.00,0.00,0.00,'0000-00-00',NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Fiches_Art` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_ArtPromo`
--

DROP TABLE IF EXISTS `Fiches_ArtPromo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_ArtPromo` (
  `code_promo` char(6) NOT NULL,
  `code` varchar(15) NOT NULL DEFAULT '',
  `libelle` varchar(50) DEFAULT NULL,
  `pmp` decimal(12,3) DEFAULT NULL,
  `pht` decimal(12,3) DEFAULT NULL,
  `pttc` decimal(12,3) DEFAULT NULL,
  `qte` decimal(12,3) DEFAULT NULL,
  PRIMARY KEY (`code_promo`,`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_ArtPromo`
--

LOCK TABLES `Fiches_ArtPromo` WRITE;
/*!40000 ALTER TABLE `Fiches_ArtPromo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_ArtPromo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Avoirs`
--

DROP TABLE IF EXISTS `Fiches_Avoirs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Avoirs` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(30) DEFAULT NULL,
  `dte` char(17) DEFAULT NULL,
  `montant` decimal(12,2) DEFAULT NULL,
  `montantdu` decimal(12,2) DEFAULT NULL,
  `ntk` char(7) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Avoirs`
--

LOCK TABLES `Fiches_Avoirs` WRITE;
/*!40000 ALTER TABLE `Fiches_Avoirs` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Avoirs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Bordereaux`
--

DROP TABLE IF EXISTS `Fiches_Bordereaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Bordereaux` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `banque` int(1) DEFAULT NULL,
  `codeentree` int(1) DEFAULT NULL,
  `dateremise` date DEFAULT NULL,
  `refremise` char(11) DEFAULT NULL,
  `datevaleur` date DEFAULT NULL,
  `ech1` date DEFAULT NULL,
  `ech2` date DEFAULT NULL,
  `bordereau` int(11) DEFAULT NULL,
  `tot` decimal(12,2) DEFAULT NULL,
  `etat` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Bordereaux`
--

LOCK TABLES `Fiches_Bordereaux` WRITE;
/*!40000 ALTER TABLE `Fiches_Bordereaux` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Bordereaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Caisses`
--

DROP TABLE IF EXISTS `Fiches_Caisses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Caisses` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(2) DEFAULT NULL,
  `intitule` varchar(30) DEFAULT NULL,
  `dteov` date DEFAULT NULL,
  `dtefm` date DEFAULT NULL,
  `fndc` decimal(12,2) DEFAULT NULL,
  `dntk` char(7) DEFAULT NULL,
  `tkz` int(1) DEFAULT NULL,
  `connecte` int(1) DEFAULT NULL,
  `imp` char(15) DEFAULT NULL,
  `typeimp` char(10) DEFAULT NULL,
  `type` char(20) DEFAULT NULL,
  `ecole` tinyint(4) DEFAULT NULL,
  `poste` char(20) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Caisses`
--

LOCK TABLES `Fiches_Caisses` WRITE;
/*!40000 ALTER TABLE `Fiches_Caisses` DISABLE KEYS */;
INSERT INTO `Fiches_Caisses` VALUES (3,'1','Caisse 1','2015-01-31','2015-01-31',457.45,'1000000',1,NULL,'DÃ©faut',NULL,'Monoposte',NULL,'jack-plessis');
/*!40000 ALTER TABLE `Fiches_Caisses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Carte`
--

DROP TABLE IF EXISTS `Fiches_Carte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Carte` (
  `code` char(13) NOT NULL,
  `rs_soc` char(9) DEFAULT NULL,
  `nom` varchar(35) DEFAULT NULL,
  `pnm` varchar(35) DEFAULT NULL,
  `adr1` varchar(35) DEFAULT NULL,
  `adr2` varchar(35) DEFAULT NULL,
  `cd_ptl` char(5) DEFAULT NULL,
  `ville` varchar(35) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `tel_bur` varchar(16) DEFAULT NULL,
  `tel_dom` varchar(16) DEFAULT NULL,
  `tel_poste` varchar(16) DEFAULT NULL,
  `pble` varchar(16) DEFAULT NULL,
  `fx1` varchar(16) DEFAULT NULL,
  `fx2` varchar(16) DEFAULT NULL,
  `datec` date DEFAULT NULL,
  `datef` date DEFAULT NULL,
  `rem` tinyint(4) DEFAULT NULL,
  `promo` tinyint(4) DEFAULT NULL,
  `tp1` decimal(12,3) DEFAULT NULL,
  `tp2` decimal(12,3) DEFAULT NULL,
  `tg1` decimal(12,3) DEFAULT NULL,
  `tg2` decimal(12,3) DEFAULT NULL,
  `obs` text,
  `cb` char(13) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Carte`
--

LOCK TABLES `Fiches_Carte` WRITE;
/*!40000 ALTER TABLE `Fiches_Carte` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Carte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_CdBarre`
--

DROP TABLE IF EXISTS `Fiches_CdBarre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_CdBarre` (
  `codep` varchar(15) NOT NULL DEFAULT '',
  `codeb` char(13) NOT NULL,
  PRIMARY KEY (`codep`,`codeb`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_CdBarre`
--

LOCK TABLES `Fiches_CdBarre` WRITE;
/*!40000 ALTER TABLE `Fiches_CdBarre` DISABLE KEYS */;
INSERT INTO `Fiches_CdBarre` VALUES ('001','2148413200001'),('002','2640636100002'),('003','');
/*!40000 ALTER TABLE `Fiches_CdBarre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Cequ`
--

DROP TABLE IF EXISTS `Fiches_Cequ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Cequ` (
  `codep` char(15) NOT NULL,
  `codequ` char(15) NOT NULL,
  PRIMARY KEY (`codep`,`codequ`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Cequ`
--

LOCK TABLES `Fiches_Cequ` WRITE;
/*!40000 ALTER TABLE `Fiches_Cequ` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Cequ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Cli`
--

DROP TABLE IF EXISTS `Fiches_Cli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Cli` (
  `cli_code` int(11) NOT NULL DEFAULT '0',
  `cli_col` varchar(1) DEFAULT NULL,
  `cli_rs_soc` varchar(12) DEFAULT NULL,
  `cli_nom` varchar(35) DEFAULT NULL,
  `cli_pnm` varchar(35) DEFAULT NULL,
  `cli_adr1` varchar(35) DEFAULT NULL,
  `cli_adr2` varchar(35) DEFAULT NULL,
  `cli_cd_ptl` varchar(5) DEFAULT NULL,
  `cli_ville` varchar(35) DEFAULT NULL,
  `cli_email` varchar(150) DEFAULT NULL,
  `cli_tel_bur` varchar(16) DEFAULT NULL,
  `cli_tel_dom` varchar(16) DEFAULT NULL,
  `cli_tel_poste` varchar(16) DEFAULT NULL,
  `cli_pble` varchar(16) DEFAULT NULL,
  `cli_fx1` varchar(16) DEFAULT NULL,
  `cli_fx2` varchar(16) DEFAULT NULL,
  `cli_plaf_ecrs` varchar(10) DEFAULT NULL,
  `cli_cd_bq` varchar(5) DEFAULT NULL,
  `cli_cd_gch` varchar(5) DEFAULT NULL,
  `cli_dmln` varchar(30) DEFAULT NULL,
  `cli_cle_rib` varchar(2) DEFAULT NULL,
  `cli_num_cpt` char(11) DEFAULT NULL,
  `cli_dom` varchar(25) DEFAULT NULL,
  `cli_cd_ent` varchar(1) DEFAULT NULL,
  `cli_cd_acc` varchar(1) DEFAULT NULL,
  `cli_ref_tir` varchar(10) DEFAULT NULL,
  `cli_id_tva` char(15) DEFAULT NULL,
  `cli_cd_soc` varchar(2) DEFAULT NULL,
  `cli_cd_cli` varchar(16) DEFAULT NULL,
  `cli_co_vtl` varchar(255) DEFAULT NULL,
  `cli_rlvc` int(11) DEFAULT NULL,
  `cli_rlvf` int(11) DEFAULT NULL,
  `cli_dt_rlc` datetime DEFAULT NULL,
  `cli_nm_int` varchar(25) DEFAULT NULL,
  `cli_obs` text,
  `cli_collectif` varchar(8) DEFAULT NULL,
  `cli_rmo` varchar(6) DEFAULT NULL,
  `cli_rart` varchar(6) DEFAULT NULL,
  `cli_exo` int(11) DEFAULT NULL,
  `cli_cdech` varchar(2) DEFAULT NULL,
  `cli_typec` char(2) DEFAULT NULL,
  `cli_expl` char(1) DEFAULT NULL,
  `cli_pays` char(30) DEFAULT NULL,
  `cli_statut` char(2) DEFAULT NULL,
  `cli_rs_soc2` char(9) DEFAULT NULL,
  `cli_nom2` varchar(35) DEFAULT NULL,
  `cli_pnm2` varchar(35) DEFAULT NULL,
  `cli_adr12` varchar(35) DEFAULT NULL,
  `cli_adr22` varchar(35) DEFAULT NULL,
  `cli_cd_ptl2` char(5) DEFAULT NULL,
  `cli_ville2` varchar(35) DEFAULT NULL,
  `cli_cnt1` char(17) DEFAULT NULL,
  `cli_cnt2` char(40) DEFAULT NULL,
  `cli_cnt3` char(25) DEFAULT NULL,
  `cli_cnt4` char(17) DEFAULT NULL,
  `cli_cnt5` char(40) DEFAULT NULL,
  `cli_cnt6` char(25) DEFAULT NULL,
  `cli_cnt7` char(17) DEFAULT NULL,
  `cli_cnt8` char(40) DEFAULT NULL,
  `cli_cnt9` char(25) DEFAULT NULL,
  `cli_cnt10` char(17) DEFAULT NULL,
  `cli_cnt11` char(40) DEFAULT NULL,
  `cli_cnt12` char(25) DEFAULT NULL,
  `cli_cnt13` char(17) DEFAULT NULL,
  `cli_cnt14` char(40) DEFAULT NULL,
  `cli_cnt15` char(25) DEFAULT NULL,
  `cli_reg` char(15) DEFAULT NULL,
  `cli_copie` tinyint(1) DEFAULT NULL,
  `cli_actif` tinyint(1) DEFAULT NULL,
  `cli_div` tinyint(1) DEFAULT NULL,
  `cli_iban` char(30) DEFAULT NULL,
  `cli_bic` char(11) DEFAULT NULL,
  `cli_coop` tinyint(1) DEFAULT NULL,
  `cli_rum` char(30) DEFAULT NULL,
  `cli_datab` char(2) DEFAULT NULL,
  `cli_aban` varchar(15) DEFAULT NULL,
  `cli_sage` char(10) DEFAULT NULL,
  PRIMARY KEY (`cli_code`),
  KEY `cli_code` (`cli_code`),
  KEY `cli_nom` (`cli_nom`),
  KEY `cli_adr1` (`cli_adr1`),
  KEY `cli_adr2` (`cli_adr2`),
  KEY `cli_cd_ptl` (`cli_cd_ptl`),
  KEY `cli_ville` (`cli_ville`),
  KEY `id_code` (`cli_code`),
  KEY `id_nom` (`cli_nom`),
  KEY `id_adr1` (`cli_adr1`),
  KEY `id_adr2` (`cli_adr2`),
  KEY `id_cdptl` (`cli_cd_ptl`),
  KEY `id_ville` (`cli_ville`),
  KEY `cli_statut` (`cli_statut`),
  KEY `cli_actif` (`cli_actif`),
  KEY `cli_statut_2` (`cli_statut`),
  KEY `cli_actif_2` (`cli_actif`),
  KEY `cli_statut_3` (`cli_statut`),
  KEY `cli_actif_3` (`cli_actif`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Cli`
--

LOCK TABLES `Fiches_Cli` WRITE;
/*!40000 ALTER TABLE `Fiches_Cli` DISABLE KEYS */;
INSERT INTO `Fiches_Cli` VALUES (411001,NULL,NULL,'A Divers ',NULL,NULL,NULL,NULL,NULL,'laurus@laurux.fr',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,'','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411002,NULL,NULL,'B Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,'','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411003,NULL,NULL,'C Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,'','','','','','','','','','','','','','','','','','','','','','',NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411004,NULL,NULL,'D Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,NULL,NULL,NULL,NULL),(411005,NULL,NULL,'E Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411006,NULL,NULL,'F Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411007,NULL,NULL,'G Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411008,NULL,NULL,'H Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411009,NULL,NULL,'I Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411010,NULL,NULL,'J Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411011,NULL,NULL,'K Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411012,NULL,NULL,'L Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411013,NULL,NULL,'M Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411014,NULL,NULL,'N Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411015,NULL,NULL,'O Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411016,NULL,NULL,'P Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411017,NULL,NULL,'Q Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411018,NULL,NULL,'R Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411019,NULL,NULL,'S Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411020,NULL,NULL,'T Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411021,NULL,NULL,'U Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411022,NULL,NULL,'V Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411023,NULL,NULL,'W Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411024,NULL,NULL,'X Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411025,NULL,NULL,'Y Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411026,NULL,NULL,'Z Divers ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,'411000','0,00','0,00',0,'00',NULL,'2','France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Fiches_Cli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Clid`
--

DROP TABLE IF EXISTS `Fiches_Clid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Clid` (
  `adr` varchar(200) DEFAULT NULL,
  `ddate` date DEFAULT NULL,
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Clid`
--

LOCK TABLES `Fiches_Clid` WRITE;
/*!40000 ALTER TABLE `Fiches_Clid` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Clid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_ClientCaisse`
--

DROP TABLE IF EXISTS `Fiches_ClientCaisse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_ClientCaisse` (
  `lInd` tinyint(4) NOT NULL AUTO_INCREMENT,
  `code` varchar(8) DEFAULT NULL,
  `nom` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_ClientCaisse`
--

LOCK TABLES `Fiches_ClientCaisse` WRITE;
/*!40000 ALTER TABLE `Fiches_ClientCaisse` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_ClientCaisse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Commentaires`
--

DROP TABLE IF EXISTS `Fiches_Commentaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Commentaires` (
  `numcom` varchar(2) NOT NULL,
  `intitule` text,
  PRIMARY KEY (`numcom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Commentaires`
--

LOCK TABLES `Fiches_Commentaires` WRITE;
/*!40000 ALTER TABLE `Fiches_Commentaires` DISABLE KEYS */;
INSERT INTO `Fiches_Commentaires` VALUES ('01','Garantie 6 mois pieces et main d\'oeuvre'),('02','Garantie 12 mois pieces et main d\'oeuvre');
/*!40000 ALTER TABLE `Fiches_Commentaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Comptes`
--

DROP TABLE IF EXISTS `Fiches_Comptes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Comptes` (
  `compte_cc` int(11) NOT NULL DEFAULT '0',
  `intitule_cc` varchar(40) DEFAULT NULL,
  `type_cc` varchar(1) DEFAULT NULL,
  `coll` int(11) DEFAULT NULL,
  `coll_cc` varchar(8) DEFAULT NULL,
  `cent_cc` int(11) DEFAULT NULL,
  `comptr_cc` int(11) DEFAULT NULL,
  `code_tvente` varchar(1) DEFAULT NULL,
  `taux_tvente` varchar(5) DEFAULT NULL,
  `gen_tv` int(11) DEFAULT NULL,
  `code_tachat` varchar(1) DEFAULT NULL,
  `taux_tachat` varchar(5) DEFAULT NULL,
  `gen_ta` int(11) DEFAULT NULL,
  `solde` double DEFAULT NULL,
  `soldep` double DEFAULT NULL,
  `cprincipal` tinyint(1) DEFAULT NULL,
  `lettrable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`compte_cc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Comptes`
--

LOCK TABLES `Fiches_Comptes` WRITE;
/*!40000 ALTER TABLE `Fiches_Comptes` DISABLE KEYS */;
INSERT INTO `Fiches_Comptes` VALUES (401000,'Collectif fournisseur','B',1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL),(411000,'Collectif client','B',1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL),(445660,'Tva sur achat 2.10','B',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(445710,'Tva sur ventes 2.10','B',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(512000,'Banque','B',0,NULL,0,1,'','',0,'','',0,0,0,0,NULL),(530000,'Caisse','B',0,NULL,0,-1,'','',0,'','',0,0,0,0,NULL),(607000,'Achat de marchandises 2.10','G',0,NULL,0,0,'','',0,'1','2.10',1,0,0,0,NULL),(707000,'Ventes marchandises 2.10','G',0,NULL,0,0,'1','2.10',1,'','',0,0,0,0,NULL),(401001,'A Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411001,'A Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(445720,'Tva sur ventes 5.50','B',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(445730,'Tva sur ventes 19.60','B',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(401002,'B Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401003,'C Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401004,'D Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401005,'E Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401006,'F Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401007,'G Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401008,'H Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401009,'I Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401010,'J Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401011,'K Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401012,'L Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401013,'M Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401014,'N Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401015,'O Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401016,'P Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401017,'Q Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401018,'R Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401019,'S Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401020,'T Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401021,'U Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401022,'V Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401023,'W Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401024,'X Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401025,'Y Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(401026,'Z Divers ','F',0,'401000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411002,'B Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411003,'C Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411004,'D Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411005,'E Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411006,'F Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411007,'G Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411008,'H Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411009,'I Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411010,'J Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411011,'K Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411012,'L Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411013,'M Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411014,'N Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411015,'O Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411016,'P Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411017,'Q Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411018,'R Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411019,'S Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411020,'T Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411021,'U Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411022,'V Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411023,'W Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411024,'X Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411025,'Y Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(411026,'Z Divers ','C',0,'411000',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,1),(445670,'Tva sur achat 5.50','B',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(445680,'Tva sur achat 19.60','B',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(607010,'Achat de marchandises 5.50','G',0,NULL,0,0,'','',0,'2','5.50',1,0,0,0,NULL),(607020,'Achat de marchandises 19.60','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(707010,'Ventes marchandises 5.50','G',0,NULL,0,0,'2','5.50',1,'','',0,0,0,0,NULL),(707020,'Ventes marchandises 19.60','G',0,NULL,0,0,'3','19.60',1,'','',0,0,0,0,NULL),(709000,'RRR accordes','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(658000,'Charges diverses gestion','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(758000,'Produits sur gestion courante','G',0,NULL,1,0,'','',0,'','',0,0,0,0,NULL),(101000,'Capital','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(106800,'Autres reserves','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(108000,'Exploitant','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(120000,'Resultat. Benefices','B',0,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,NULL),(129000,'Resultat. Perte','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(110000,'Report a nouveau credit','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(119000,'Report a nouveau debit','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(168800,'Interets courus','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(211000,'Terrain','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(213000,'Construction','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(213500,'Inst. Gen. Agen. Ame.','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(218200,'Materiel de transport','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(218300,'Materiel bureau informatique','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(218400,'Mobilier','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(231000,'Immobilisation en cours','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(231500,'Amenagement en cours','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(261000,'Titres de participation','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(266000,'Autres formes de participation','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(275000,'Depots et cautionnements','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(281300,'Amortissement construction','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(218820,'Amortissement materiels de transport','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(281400,'Amortissement mobilier','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(281500,'Amortissement materiel de bureau','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(281600,'Amortissement materiel de transport','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(281700,'Amortissement materiel informatique','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(335000,'Travaux en cours','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(370000,'Stock marchandises','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(397000,'Provision depreciation stock','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(408000,'Factures non parvenues','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(408100,'Fournisseurs factures non parvenues','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(409600,'Fourniseurs emballages a rendre','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(409700,'Avoirs non parvenus','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(416000,'Clients douteux','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(421000,'Remuneration employes','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(428200,'Provisions conges payes','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(437100,'Organismes sociaux','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(437200,'Retraite employes','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(444000,'Impots societes','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(445510,'Tva a decaisser','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(445620,'Tva deductible sur immobilisation','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(471000,'Compte d\'attente','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(491000,'Provisions pour creances','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(518600,'Interets courus','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(580000,'Virements internes','B',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(605000,'Sous traitance','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606110,'Electricite','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606120,'Gaz','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(606130,'Eau, assainissement','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606150,'Carburant','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(606170,'Gas-oil','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606300,'Fournitures entretien','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606400,'Fournitures administratives','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606410,'Fournitures informatiques','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606800,'Matieres consommables','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(606810,'Produits entretien','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(622603,'Centre agree de gestion','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(622604,'Honoraires divers','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(622605,'Comptable','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(622700,'Frais actes et contentieux','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(623100,'Annonces','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(623400,'Cadeaux clientele','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(623700,'Publicite','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(623705,'Publicite exo','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(623800,'Dons','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(625100,'Voyages et deplacements','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(625600,'Missions','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(626100,'Frais postaux','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(625500,'Frais internet','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(627000,'Frais bancaires','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(627200,'Frais/emis emprunt','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(627800,'Frais factures','G',0,NULL,0,0,'','',0,'3','19.60',1,0,0,0,NULL),(631200,'Taxe apprentissage','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(633300,'Participation employeur formation prof.','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(635110,'Taxe professionnelle','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(635120,'Taxe fonciere','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(635150,'Taxes diveres','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(637100,'Contibution sociale solidarite','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(637810,'Csg deductible','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(637820,'Csg non deductible','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(641100,'Salaires bruts','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(641200,'Charges personnels conges payes','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(641400,'Remboursement maladie','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(644000,'Remuneration exploitant','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(645320,'Retraite employes','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(645500,'Provisions charges conges','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(645800,'Charges sociales','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(646200,'Cotisations maladies','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(646210,'Maladie complementaire','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(646300,'Cotisations retraite','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(647500,'Medecine du travail','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(671800,'Pertes stock','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(678000,'Charges exceptionnelles','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(681120,'Dotations amortissements','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(681730,'Depreciation stock','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(695100,'Impots sur les benefices','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(705000,'Sous-traitance','G',0,NULL,0,0,'3','19.60',1,'','',0,0,0,0,NULL),(706100,'Ventes MO','G',0,NULL,0,0,'3','19.60',1,'','',0,0,0,0,NULL),(512001,'Banque 2','B',0,NULL,0,1,'','',0,'','',0,0,0,0,NULL),(609700,'RRR obtenus','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(709700,'RRR accordÃ©s','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(603700,'Variations de stock','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(602100,'Matieres consommables','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(604000,'Achats de sous-traitance','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(606100,'Fournitures non stockables','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(612200,'Credit bail mobilier','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(613200,'Locations immobiliers','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(641110,'Salaires productifs','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(645000,'Charges SS et prevoyance','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(654100,'Pertes/crÃ©ances irr. e.','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(661100,'Interets sur emprunts','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(671000,'Charges exceptionnelles/OpÃ©ration gesti','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(706110,'Prestations services 19.60','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(722000,'Production immobilisÃ©e','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(791000,'Transferts charges','G',0,NULL,0,0,'','',0,'','',0,0,0,0,NULL),(580001,'Virements internes cartes','B',0,NULL,0,0,'','',0,'','',0,0,NULL,0,NULL),(580002,'Virements internes chÃ¨ques','B',0,NULL,0,0,'','',0,'','',0,0,NULL,0,NULL),(580003,'Virements internes autres','B',0,NULL,0,0,'','',0,'','',0,0,NULL,0,NULL),(606306,'Petit outillage','G',0,NULL,0,0,NULL,NULL,0,'3','19.60',1,0,NULL,0,NULL);
/*!40000 ALTER TABLE `Fiches_Comptes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Cpostaux`
--

DROP TABLE IF EXISTS `Fiches_Cpostaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Cpostaux` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `cp` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `burdist` char(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Cpostaux`
--

LOCK TABLES `Fiches_Cpostaux` WRITE;
/*!40000 ALTER TABLE `Fiches_Cpostaux` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Cpostaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Cpostaux01`
--

DROP TABLE IF EXISTS `Fiches_Cpostaux01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Cpostaux01` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `cp` char(5) NOT NULL,
  `burdist` char(35) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Cpostaux01`
--

LOCK TABLES `Fiches_Cpostaux01` WRITE;
/*!40000 ALTER TABLE `Fiches_Cpostaux01` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Cpostaux01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Depots`
--

DROP TABLE IF EXISTS `Fiches_Depots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Depots` (
  `code` char(8) NOT NULL DEFAULT '',
  `libelle` varchar(35) DEFAULT NULL,
  `adr1` varchar(35) DEFAULT NULL,
  `adr2` varchar(35) DEFAULT NULL,
  `cp` char(5) DEFAULT NULL,
  `ville` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Depots`
--

LOCK TABLES `Fiches_Depots` WRITE;
/*!40000 ALTER TABLE `Fiches_Depots` DISABLE KEYS */;
INSERT INTO `Fiches_Depots` VALUES ('01','Magasin','','','',''),('02','DÃ©pot 1','','','','');
/*!40000 ALTER TABLE `Fiches_Depots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Echeances`
--

DROP TABLE IF EXISTS `Fiches_Echeances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Echeances` (
  `num` varchar(2) NOT NULL,
  `libell` varchar(20) DEFAULT NULL,
  `duree` varchar(2) DEFAULT NULL,
  `finmois` tinyint(1) DEFAULT NULL,
  `jours` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Echeances`
--

LOCK TABLES `Fiches_Echeances` WRITE;
/*!40000 ALTER TABLE `Fiches_Echeances` DISABLE KEYS */;
INSERT INTO `Fiches_Echeances` VALUES ('00','Comptant','00',0,'00'),('01','30 jours fin de mois','30',1,'00'),('02','30 jours le 5','30',0,'05'),('03','30 jours le 10','30',0,'10'),('04','30 jours le 15','30',0,'15'),('05','30 jours le 20','30',0,'20'),('06','30 jours le 25','30',0,'25'),('07','30 jours','30',0,'00'),('08','60 jours fin de mois','60',1,'00'),('09','60 jours le 5','60',0,'05'),('10','60 jours le 10','60',0,'10'),('11','60 jours le 15','60',0,'15'),('12','60 jours le 20','60',0,'20'),('13','60 jours le 25','60',0,'25'),('14','60 jours','60',0,'00'),('15','45 jours','45',0,'00');
/*!40000 ALTER TABLE `Fiches_Echeances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_EntTickets1`
--

DROP TABLE IF EXISTS `Fiches_EntTickets1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_EntTickets1` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `caisse` char(1) DEFAULT NULL,
  `vendeur` char(35) DEFAULT NULL,
  `numero` char(7) DEFAULT NULL,
  `date` char(17) DEFAULT NULL,
  `client` char(30) DEFAULT NULL,
  `scheque` char(1) DEFAULT NULL,
  `mcheque` char(12) DEFAULT NULL,
  `nmcheque` char(30) DEFAULT NULL,
  `scarte` char(1) DEFAULT NULL,
  `nmcarte` char(30) DEFAULT NULL,
  `mcarte` char(12) DEFAULT NULL,
  `sespeces` char(1) DEFAULT NULL,
  `mespeces` char(12) DEFAULT NULL,
  `scredit` char(1) DEFAULT NULL,
  `mcredit` char(12) DEFAULT NULL,
  `nmcredit` char(30) DEFAULT NULL,
  `sbachat` char(1) DEFAULT NULL,
  `mbachat` char(12) DEFAULT NULL,
  `scavoir` char(1) DEFAULT NULL,
  `mavoir` char(12) DEFAULT NULL,
  `nmavoir` char(30) DEFAULT NULL,
  `sbonus` char(1) DEFAULT NULL,
  `mbonus` char(12) DEFAULT NULL,
  `mht` char(12) DEFAULT NULL,
  `mtva` char(12) DEFAULT NULL,
  `mttc` char(12) DEFAULT NULL,
  `statut` char(1) DEFAULT NULL,
  `savoir` char(1) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `mrem` char(12) DEFAULT NULL,
  `carte` char(13) DEFAULT NULL,
  `points` decimal(12,3) DEFAULT NULL,
  `sresto` char(1) DEFAULT NULL,
  `mresto` char(12) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_EntTickets1`
--

LOCK TABLES `Fiches_EntTickets1` WRITE;
/*!40000 ALTER TABLE `Fiches_EntTickets1` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_EntTickets1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_EntTicketz`
--

DROP TABLE IF EXISTS `Fiches_EntTicketz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_EntTicketz` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `caisse` char(2) DEFAULT NULL,
  `numero` char(7) DEFAULT NULL,
  `date` char(17) DEFAULT NULL,
  `client` varchar(30) DEFAULT NULL,
  `scheque` char(1) DEFAULT NULL,
  `mcheque` char(12) DEFAULT NULL,
  `nmcheque` varchar(30) DEFAULT NULL,
  `scarte` char(1) DEFAULT NULL,
  `nmcarte` varchar(30) DEFAULT NULL,
  `mcarte` char(12) DEFAULT NULL,
  `sespeces` char(1) DEFAULT NULL,
  `mespeces` char(12) DEFAULT NULL,
  `scredit` char(1) DEFAULT NULL,
  `mcredit` char(12) DEFAULT NULL,
  `nmcredit` varchar(30) DEFAULT NULL,
  `sbachat` char(1) DEFAULT NULL,
  `mbachat` char(12) DEFAULT NULL,
  `scavoir` char(1) DEFAULT NULL,
  `mavoir` char(12) DEFAULT NULL,
  `nmavoir` varchar(30) DEFAULT NULL,
  `mht` char(12) DEFAULT NULL,
  `mtva` char(12) DEFAULT NULL,
  `mttc` char(12) DEFAULT NULL,
  `statut` char(1) DEFAULT NULL,
  `savoir` char(1) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `mrem` char(12) DEFAULT NULL,
  `vendeur` varchar(35) DEFAULT NULL,
  `carte` char(13) DEFAULT NULL,
  `points` decimal(12,3) DEFAULT NULL,
  `sbonus` char(1) DEFAULT NULL,
  `mbonus` char(12) DEFAULT NULL,
  `sresto` char(1) DEFAULT NULL,
  `mresto` char(12) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_EntTicketz`
--

LOCK TABLES `Fiches_EntTicketz` WRITE;
/*!40000 ALTER TABLE `Fiches_EntTicketz` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_EntTicketz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Fam`
--

DROP TABLE IF EXISTS `Fiches_Fam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Fam` (
  `code_fam` varchar(5) NOT NULL,
  `libell_fam` varchar(30) DEFAULT NULL,
  `compt_fam` varchar(8) DEFAULT NULL,
  `coef_fam` decimal(6,3) DEFAULT NULL,
  `cdtva_fam` varchar(1) DEFAULT NULL,
  `txtva_fam` double DEFAULT NULL,
  `cptrem_fam` varchar(10) DEFAULT NULL,
  `ect_fam` double DEFAULT NULL,
  `rem_fam` double DEFAULT NULL,
  `qte1` double DEFAULT NULL,
  `qte2` double DEFAULT NULL,
  `rem1` double DEFAULT NULL,
  `qte3` double DEFAULT NULL,
  `qte4` double DEFAULT NULL,
  `rem2` double DEFAULT NULL,
  `qte5` double DEFAULT NULL,
  `qte6` double DEFAULT NULL,
  `rem3` double DEFAULT NULL,
  `qte7` double DEFAULT NULL,
  `qte8` double DEFAULT NULL,
  `rem4` double DEFAULT NULL,
  `qte9` double DEFAULT NULL,
  `qte10` double DEFAULT NULL,
  `rem5` double DEFAULT NULL,
  `qte11` double DEFAULT NULL,
  `qte12` double DEFAULT NULL,
  `rem6` double DEFAULT NULL,
  `compt2_fam` char(8) DEFAULT NULL,
  `compt3_fam` char(8) DEFAULT NULL,
  PRIMARY KEY (`code_fam`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Fam`
--

LOCK TABLES `Fiches_Fam` WRITE;
/*!40000 ALTER TABLE `Fiches_Fam` DISABLE KEYS */;
INSERT INTO `Fiches_Fam` VALUES ('01','Produits 2.10','707000',2.200,'1',2.1,'709000',NULL,0,0,10,0,10.01,50,2,50.01,100,4,100.01,500,10,500.01,9999999.99,15,10000000,NULL,NULL,'707000','602100'),('10','Mo','706100',2.000,'3',19.6,'709000',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'706100','605000'),('02','Produits 5.50','707010',2.000,'2',5.5,'709000',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'707010','606300'),('03','Produits 19.60','707020',1.800,'3',19.6,'709000',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'707020','606306');
/*!40000 ALTER TABLE `Fiches_Fam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_HisEntTickets`
--

DROP TABLE IF EXISTS `Fiches_HisEntTickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_HisEntTickets` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `caisse` char(2) DEFAULT NULL,
  `numero` char(7) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `client` varchar(30) DEFAULT NULL,
  `scheque` char(1) DEFAULT NULL,
  `mcheque` char(12) DEFAULT NULL,
  `nmcheque` varchar(30) DEFAULT NULL,
  `scarte` char(1) DEFAULT NULL,
  `nmcarte` varchar(30) DEFAULT NULL,
  `mcarte` char(12) DEFAULT NULL,
  `sespeces` char(1) DEFAULT NULL,
  `mespeces` char(12) DEFAULT NULL,
  `scredit` char(1) DEFAULT NULL,
  `mcredit` char(12) DEFAULT NULL,
  `nmcredit` varchar(30) DEFAULT NULL,
  `sbachat` char(1) DEFAULT NULL,
  `mbachat` char(12) DEFAULT NULL,
  `scavoir` char(1) DEFAULT NULL,
  `mavoir` char(12) DEFAULT NULL,
  `nmavoir` varchar(30) DEFAULT NULL,
  `mht` char(12) DEFAULT NULL,
  `mtva` char(12) DEFAULT NULL,
  `mttc` char(12) DEFAULT NULL,
  `savoir` char(1) DEFAULT NULL,
  `vendeur` varchar(35) DEFAULT NULL,
  `carte` char(13) DEFAULT NULL,
  `points` decimal(12,3) DEFAULT NULL,
  `sbonus` char(1) DEFAULT NULL,
  `mbonus` char(12) DEFAULT NULL,
  `sresto` char(1) DEFAULT NULL,
  `mresto` char(12) DEFAULT NULL,
  PRIMARY KEY (`lInd`),
  KEY `numero` (`numero`),
  KEY `caisse` (`caisse`),
  KEY `numero_2` (`numero`),
  KEY `date` (`date`),
  KEY `vendeur` (`vendeur`),
  KEY `carte` (`carte`),
  KEY `id_caisse` (`caisse`),
  KEY `id_numero` (`numero`),
  KEY `id_date` (`date`),
  KEY `id_vendeur` (`vendeur`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_HisEntTickets`
--

LOCK TABLES `Fiches_HisEntTickets` WRITE;
/*!40000 ALTER TABLE `Fiches_HisEntTickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_HisEntTickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_HisLigTickets`
--

DROP TABLE IF EXISTS `Fiches_HisLigTickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_HisLigTickets` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `numero` char(7) DEFAULT NULL,
  `numlig` char(3) DEFAULT NULL,
  `code` varchar(15) DEFAULT NULL,
  `intitule` varchar(35) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `qte` char(12) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `fam` char(5) DEFAULT NULL,
  `mht` char(12) DEFAULT NULL,
  `mrem` char(12) DEFAULT NULL,
  `tva` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`lInd`),
  KEY `numero` (`numero`),
  KEY `numero_2` (`numero`),
  KEY `numlig` (`numlig`),
  KEY `code` (`code`),
  KEY `type` (`type`),
  KEY `id_numero` (`numero`),
  KEY `id_numlig` (`numlig`),
  KEY `id_code` (`code`),
  KEY `id_type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_HisLigTickets`
--

LOCK TABLES `Fiches_HisLigTickets` WRITE;
/*!40000 ALTER TABLE `Fiches_HisLigTickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_HisLigTickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Identite`
--

DROP TABLE IF EXISTS `Fiches_Identite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Identite` (
  `code` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `libelle` char(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Identite`
--

LOCK TABLES `Fiches_Identite` WRITE;
/*!40000 ALTER TABLE `Fiches_Identite` DISABLE KEYS */;
INSERT INTO `Fiches_Identite` VALUES ('01','SARL'),('02','EARL'),('03','SA'),('04','EURL'),('05','SNC'),('06','SE'),('07','M.'),('08','Mme'),('09','Mme et M.'),('10','Gaec'),('11','CI'),('12','GIE'),('13','SAS'),('14','SASU'),('15','SCI'),('16','SCM'),('17','SCOP'),('18','SCP'),('19','SEL'),('20','SDF'),('21','SCS'),('22','SELARL'),('23','SEP');
/*!40000 ALTER TABLE `Fiches_Identite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Inv`
--

DROP TABLE IF EXISTS `Fiches_Inv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Inv` (
  `inv_nlig` char(9) NOT NULL DEFAULT '',
  `inv_code` varchar(15) DEFAULT NULL,
  `inv_qtestock` double DEFAULT NULL,
  `inv_qtecomptee` double DEFAULT NULL,
  `inv_date` datetime DEFAULT NULL,
  `inv_comptee` int(11) DEFAULT NULL,
  `inv_valid` int(11) DEFAULT NULL,
  PRIMARY KEY (`inv_nlig`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Inv`
--

LOCK TABLES `Fiches_Inv` WRITE;
/*!40000 ALTER TABLE `Fiches_Inv` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Inv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_InvT`
--

DROP TABLE IF EXISTS `Fiches_InvT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_InvT` (
  `inv_nlig` char(9) NOT NULL DEFAULT '',
  `inv_code` varchar(15) DEFAULT NULL,
  `inv_qtestock` double DEFAULT NULL,
  `inv_qtecomptee` double DEFAULT NULL,
  `inv_date` datetime DEFAULT NULL,
  `inv_comptee` int(11) DEFAULT NULL,
  `inv_valid` int(11) DEFAULT NULL,
  PRIMARY KEY (`inv_nlig`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_InvT`
--

LOCK TABLES `Fiches_InvT` WRITE;
/*!40000 ALTER TABLE `Fiches_InvT` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_InvT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Lcr`
--

DROP TABLE IF EXISTS `Fiches_Lcr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Lcr` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(8) DEFAULT NULL,
  `nom` varchar(35) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `datech` date DEFAULT NULL,
  `numfac` char(12) DEFAULT NULL,
  `acceptee` int(11) DEFAULT NULL,
  `ecartee` int(11) DEFAULT NULL,
  `banque` varchar(35) DEFAULT NULL,
  `codeentree` int(1) DEFAULT NULL,
  `bordereau` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Lcr`
--

LOCK TABLES `Fiches_Lcr` WRITE;
/*!40000 ALTER TABLE `Fiches_Lcr` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Lcr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_LibelAvoirs`
--

DROP TABLE IF EXISTS `Fiches_LibelAvoirs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_LibelAvoirs` (
  `lInd` tinyint(4) NOT NULL AUTO_INCREMENT,
  `libelav` char(250) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_LibelAvoirs`
--

LOCK TABLES `Fiches_LibelAvoirs` WRITE;
/*!40000 ALTER TABLE `Fiches_LibelAvoirs` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_LibelAvoirs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_LibelFac`
--

DROP TABLE IF EXISTS `Fiches_LibelFac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_LibelFac` (
  `mind` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `txtfac` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`mind`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_LibelFac`
--

LOCK TABLES `Fiches_LibelFac` WRITE;
/*!40000 ALTER TABLE `Fiches_LibelFac` DISABLE KEYS */;
INSERT INTO `Fiches_LibelFac` VALUES (1,'\n');
/*!40000 ALTER TABLE `Fiches_LibelFac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_LibelTicket`
--

DROP TABLE IF EXISTS `Fiches_LibelTicket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_LibelTicket` (
  `lInd` tinyint(4) NOT NULL AUTO_INCREMENT,
  `libeltk` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_LibelTicket`
--

LOCK TABLES `Fiches_LibelTicket` WRITE;
/*!40000 ALTER TABLE `Fiches_LibelTicket` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_LibelTicket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Libelles`
--

DROP TABLE IF EXISTS `Fiches_Libelles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Libelles` (
  `num` varchar(2) NOT NULL,
  `intitule` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Libelles`
--

LOCK TABLES `Fiches_Libelles` WRITE;
/*!40000 ALTER TABLE `Fiches_Libelles` DISABLE KEYS */;
INSERT INTO `Fiches_Libelles` VALUES ('1','Facture'),('2','Avoir'),('3','Cheque'),('4','Carte');
/*!40000 ALTER TABLE `Fiches_Libelles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_LigTickets1`
--

DROP TABLE IF EXISTS `Fiches_LigTickets1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_LigTickets1` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `numero` char(7) DEFAULT NULL,
  `numlig` char(3) DEFAULT NULL,
  `code` char(15) DEFAULT NULL,
  `intitule` char(50) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `qte` char(12) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `fam` char(5) DEFAULT NULL,
  `mht` char(12) DEFAULT NULL,
  `mrem` char(12) DEFAULT NULL,
  `mtva` char(12) DEFAULT NULL,
  `block` char(4) DEFAULT NULL,
  `tva` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_LigTickets1`
--

LOCK TABLES `Fiches_LigTickets1` WRITE;
/*!40000 ALTER TABLE `Fiches_LigTickets1` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_LigTickets1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_LigTicketz`
--

DROP TABLE IF EXISTS `Fiches_LigTicketz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_LigTicketz` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `numero` char(7) DEFAULT NULL,
  `numlig` char(3) DEFAULT NULL,
  `code` varchar(15) DEFAULT NULL,
  `intitule` varchar(35) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `qte` char(12) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `fam` char(5) DEFAULT NULL,
  `mht` char(12) DEFAULT NULL,
  `mrem` char(12) DEFAULT NULL,
  `mtva` char(12) DEFAULT NULL,
  `block` char(4) DEFAULT NULL,
  `tva` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_LigTicketz`
--

LOCK TABLES `Fiches_LigTicketz` WRITE;
/*!40000 ALTER TABLE `Fiches_LigTicketz` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_LigTicketz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Ligabon`
--

DROP TABLE IF EXISTS `Fiches_Ligabon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Ligabon` (
  `numero` varchar(15) NOT NULL,
  `compte` varchar(10) NOT NULL,
  `intitule` varchar(40) DEFAULT NULL,
  `debit` char(10) NOT NULL,
  `credit` char(10) NOT NULL,
  `lig` int(2) DEFAULT NULL,
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Ligabon`
--

LOCK TABLES `Fiches_Ligabon` WRITE;
/*!40000 ALTER TABLE `Fiches_Ligabon` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Ligabon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Ligrecpt`
--

DROP TABLE IF EXISTS `Fiches_Ligrecpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Ligrecpt` (
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `design` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numrecpt` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `four` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `daterecpt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `qte` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pbht` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rm` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paht` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frais` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prvt` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nligne` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`code`,`numrecpt`,`four`,`daterecpt`,`nligne`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Ligrecpt`
--

LOCK TABLES `Fiches_Ligrecpt` WRITE;
/*!40000 ALTER TABLE `Fiches_Ligrecpt` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Ligrecpt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Numabon`
--

DROP TABLE IF EXISTS `Fiches_Numabon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Numabon` (
  `numero` varchar(15) NOT NULL DEFAULT '',
  `intitule` varchar(30) DEFAULT NULL,
  `type` char(1) NOT NULL,
  `typem` char(1) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Numabon`
--

LOCK TABLES `Fiches_Numabon` WRITE;
/*!40000 ALTER TABLE `Fiches_Numabon` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Numabon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Parametres`
--

DROP TABLE IF EXISTS `Fiches_Parametres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Parametres` (
  `ind` int(11) NOT NULL DEFAULT '0',
  `dteclec` datetime DEFAULT NULL,
  `dteclec1` datetime DEFAULT NULL,
  `dteclec2` datetime DEFAULT NULL,
  `dteclec3` datetime DEFAULT NULL,
  `dteclec4` datetime DEFAULT NULL,
  `dteclec5` datetime DEFAULT NULL,
  `dtepp` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtepec` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtepc` datetime DEFAULT NULL,
  `dtetdec` datetime DEFAULT NULL,
  `dtefedec` datetime DEFAULT NULL,
  `cptrplus` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cptrmoins` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jdr` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cptrsplus` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cptrsmoins` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numecriture` int(11) DEFAULT NULL,
  `dnc` int(11) DEFAULT NULL,
  `dnbon` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dnfac` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dndevis` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jrnal` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `son` int(11) NOT NULL DEFAULT '0',
  `dnf` int(11) DEFAULT NULL,
  `numecriture1` int(11) DEFAULT NULL,
  `numecriture2` int(11) DEFAULT NULL,
  `numecriture3` int(11) DEFAULT NULL,
  `coretro` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dncom` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devise` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jrnal2` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jrnal3` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `viremc` char(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `viremchq` char(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `virema` char(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jrnal4` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dteinv` date DEFAULT NULL,
  `jrnal5` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ind`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Parametres`
--

LOCK TABLES `Fiches_Parametres` WRITE;
/*!40000 ALTER TABLE `Fiches_Parametres` DISABLE KEYS */;
INSERT INTO `Fiches_Parametres` VALUES (0,'2014-12-31 00:00:00','2013-12-31 00:00:00','2012-12-31 00:00:00','2011-12-31 00:00:00','2010-12-31 00:00:00','2009-12-31 00:00:00','12.2013','01.2014','2013-12-31 00:00:00','2013-12-31 00:00:00','2013-12-31 00:00:00','758000','658000','10','120000','129000',0,411026,'000001','000000','000000','70',0,401026,0,0,0,'1,00',NULL,NULL,'53','50','580001','580002','580003','70',NULL,'60');
/*!40000 ALTER TABLE `Fiches_Parametres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_PrdComp`
--

DROP TABLE IF EXISTS `Fiches_PrdComp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_PrdComp` (
  `codep` varchar(15) NOT NULL DEFAULT '',
  `codec` varchar(50) NOT NULL DEFAULT '',
  `libelle` varchar(50) DEFAULT NULL,
  `qte` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`codep`,`codec`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_PrdComp`
--

LOCK TABLES `Fiches_PrdComp` WRITE;
/*!40000 ALTER TABLE `Fiches_PrdComp` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_PrdComp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Promo`
--

DROP TABLE IF EXISTS `Fiches_Promo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Promo` (
  `code` varchar(15) NOT NULL DEFAULT '',
  `libelle` varchar(50) DEFAULT NULL,
  `datedeb` date DEFAULT NULL,
  `datefin` date DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Promo`
--

LOCK TABLES `Fiches_Promo` WRITE;
/*!40000 ALTER TABLE `Fiches_Promo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Promo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Reglts1`
--

DROP TABLE IF EXISTS `Fiches_Reglts1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Reglts1` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` char(30) DEFAULT NULL,
  `type` char(15) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `qte` char(12) DEFAULT NULL,
  `date` char(17) DEFAULT NULL,
  `caisse` char(2) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Reglts1`
--

LOCK TABLES `Fiches_Reglts1` WRITE;
/*!40000 ALTER TABLE `Fiches_Reglts1` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Reglts1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Regltz`
--

DROP TABLE IF EXISTS `Fiches_Regltz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Regltz` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` char(30) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `qte` char(12) DEFAULT NULL,
  `type` char(15) DEFAULT NULL,
  `caisse` char(2) DEFAULT NULL,
  `date` char(17) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Regltz`
--

LOCK TABLES `Fiches_Regltz` WRITE;
/*!40000 ALTER TABLE `Fiches_Regltz` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Regltz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Sdepots`
--

DROP TABLE IF EXISTS `Fiches_Sdepots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Sdepots` (
  `Mind` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(2) NOT NULL,
  `cart` char(15) NOT NULL,
  `date` date NOT NULL,
  `type` char(1) DEFAULT NULL,
  `qte` char(10) DEFAULT NULL,
  `com` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Mind`),
  KEY `code` (`code`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Sdepots`
--

LOCK TABLES `Fiches_Sdepots` WRITE;
/*!40000 ALTER TABLE `Fiches_Sdepots` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Sdepots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Societes`
--

DROP TABLE IF EXISTS `Fiches_Societes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Societes` (
  `cd_sc` varchar(2) NOT NULL,
  `type_sc` char(9) DEFAULT NULL,
  `int_sc` varchar(35) DEFAULT NULL,
  `adr1_sc` varchar(35) DEFAULT NULL,
  `adr2_sc` varchar(35) DEFAULT NULL,
  `cp_sc` varchar(5) DEFAULT NULL,
  `burdis_sc` varchar(35) DEFAULT NULL,
  `email_sc` char(50) DEFAULT NULL,
  `rcs_sc` varchar(12) DEFAULT NULL,
  `villerc_sc` varchar(15) DEFAULT NULL,
  `siret_sc` varchar(15) DEFAULT NULL,
  `tvaintra_sc` varchar(15) DEFAULT NULL,
  `cap_sc` varchar(15) DEFAULT NULL,
  `ape_sc` varchar(5) DEFAULT NULL,
  `tel_sc` varchar(16) DEFAULT NULL,
  `fax_sc` varchar(16) DEFAULT NULL,
  `site` varchar(40) DEFAULT NULL,
  `port_sc` char(16) DEFAULT NULL,
  `banq` char(30) DEFAULT NULL,
  `bic` char(11) DEFAULT NULL,
  `libre` char(35) DEFAULT NULL,
  PRIMARY KEY (`cd_sc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Societes`
--

LOCK TABLES `Fiches_Societes` WRITE;
/*!40000 ALTER TABLE `Fiches_Societes` DISABLE KEYS */;
INSERT INTO `Fiches_Societes` VALUES ('01','SARL','Laurux',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'06',NULL,NULL,'caisse');
/*!40000 ALTER TABLE `Fiches_Societes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_SousComptes`
--

DROP TABLE IF EXISTS `Fiches_SousComptes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_SousComptes` (
  `code` char(8) NOT NULL,
  `code_vtl` char(8) NOT NULL,
  `intitule_vtl` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`code_vtl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_SousComptes`
--

LOCK TABLES `Fiches_SousComptes` WRITE;
/*!40000 ALTER TABLE `Fiches_SousComptes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_SousComptes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Statut`
--

DROP TABLE IF EXISTS `Fiches_Statut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Statut` (
  `code` char(2) NOT NULL,
  `libelle` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Statut`
--

LOCK TABLES `Fiches_Statut` WRITE;
/*!40000 ALTER TABLE `Fiches_Statut` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Statut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_StkDepots`
--

DROP TABLE IF EXISTS `Fiches_StkDepots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_StkDepots` (
  `coded` char(8) NOT NULL DEFAULT '',
  `codea` varchar(15) NOT NULL DEFAULT '',
  `qte` decimal(12,3) DEFAULT NULL,
  PRIMARY KEY (`coded`,`codea`),
  KEY `coded` (`coded`),
  KEY `codea` (`codea`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_StkDepots`
--

LOCK TABLES `Fiches_StkDepots` WRITE;
/*!40000 ALTER TABLE `Fiches_StkDepots` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_StkDepots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Ticketx1`
--

DROP TABLE IF EXISTS `Fiches_Ticketx1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Ticketx1` (
  `lInd` int(11) NOT NULL AUTO_INCREMENT,
  `numero` char(7) DEFAULT NULL,
  `fam` char(5) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `qte` char(12) DEFAULT NULL,
  PRIMARY KEY (`lInd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Ticketx1`
--

LOCK TABLES `Fiches_Ticketx1` WRITE;
/*!40000 ALTER TABLE `Fiches_Ticketx1` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Ticketx1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Tleg`
--

DROP TABLE IF EXISTS `Fiches_Tleg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Tleg` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` text,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Tleg`
--

LOCK TABLES `Fiches_Tleg` WRITE;
/*!40000 ALTER TABLE `Fiches_Tleg` DISABLE KEYS */;
INSERT INTO `Fiches_Tleg` VALUES (1,'RESERVE DE PROPRIETE: Le vendeur se rÃ©serve la proprietÃ© des marchandises jusqu\'au paiement intÃ©gral de leur prix en principal et intÃ©rÃªts, par l\'acheteur.\nLa responsabilitÃ© des marchandises est transferÃ©e dÃ¨s leur dÃ©livrance. Nos marchandises voyagent aux risques et pÃ©rils des destinataires.\nAucune piece n\'est reprise apres 8 jours de livraison, les pieces commandÃ©es spÃ©cialement ne sont jamais reprises. Sauf application des rÃ¨gles obligatoires de compÃ©tence a l\'Ã©gard des non\ncommercants, toutes contestations seront transmises aux juridictions du siege de notre entreprise.');
/*!40000 ALTER TABLE `Fiches_Tleg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Touches`
--

DROP TABLE IF EXISTS `Fiches_Touches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Touches` (
  `touche` char(6) NOT NULL DEFAULT '',
  `libelle` char(30) DEFAULT NULL,
  `code` char(15) DEFAULT NULL,
  `tva` decimal(5,2) DEFAULT NULL,
  `coul` int(11) DEFAULT NULL,
  `fond` varchar(100) DEFAULT NULL,
  `touche_s` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`touche`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Touches`
--

LOCK TABLES `Fiches_Touches` WRITE;
/*!40000 ALTER TABLE `Fiches_Touches` DISABLE KEYS */;
INSERT INTO `Fiches_Touches` VALUES ('A1','Outillage','01',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/Remises.png',-1),('A2','Quincaillerie','02',20.00,16777215,'/home/jack/Laurux3-Pos-dev/Icones/Bla.png',NULL),('A9','revetement\nsol','09',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/Clavier.png',NULL),('A10','Batiment','10',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/Fam.png',NULL),('A17','Materiel\nagricole','17',20.00,15263859,NULL,NULL),('A8','Petit\nelectro-\nmenager','8',20.00,10420091,NULL,NULL),('A15','Gros\nelectro-\nmenager','15',20.00,13631435,NULL,NULL),('A22','DÃ©coupe \nbois','22',20.00,NULL,NULL,NULL),('A29','DÃ©coupe \nverre','29',20.00,NULL,NULL,NULL),('A16','Jardinage \n20 %','16',20.00,16758896,NULL,NULL),('A23','Jardinage \n7 %','23',7.00,16770501,NULL,NULL),('A30','Motoculture','30',20.00,NULL,NULL,NULL),('A3','Sanitaire','3',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/Laurus.png',NULL),('A24','Fumisterie','24',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/credit.png',NULL),('A31','Ampoules','31',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/tip.png',NULL),('A4','TÃ©lÃ©phonie','4',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/sms.png',NULL),('A11','Fournitures \nbureau','11',20.00,16777215,'/home/jack/LX-Pos-dev/Icones/calc.png',NULL),('A1B1','Outillage Ã \nmain','01',20.00,NULL,NULL,-1),('A1B8','Outillage\nÃ©lectrique','8',20.00,NULL,NULL,-1);
/*!40000 ALTER TABLE `Fiches_Touches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Traites`
--

DROP TABLE IF EXISTS `Fiches_Traites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Traites` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(8) DEFAULT NULL,
  `montant` char(12) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `datech` date DEFAULT NULL,
  `numfac` char(12) DEFAULT NULL,
  `imp` tinyint(4) DEFAULT NULL,
  `nom` varchar(35) DEFAULT NULL,
  `acceptee` int(1) DEFAULT NULL,
  `ecartee` int(1) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Traites`
--

LOCK TABLES `Fiches_Traites` WRITE;
/*!40000 ALTER TABLE `Fiches_Traites` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Traites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Tvaac`
--

DROP TABLE IF EXISTS `Fiches_Tvaac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Tvaac` (
  `code_tva` varchar(1) NOT NULL,
  `taux_tva` varchar(5) DEFAULT NULL,
  `cc_tva` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`code_tva`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Tvaac`
--

LOCK TABLES `Fiches_Tvaac` WRITE;
/*!40000 ALTER TABLE `Fiches_Tvaac` DISABLE KEYS */;
INSERT INTO `Fiches_Tvaac` VALUES ('1','2.10','445660'),('2','5.50','445670'),('3','19.60','445680');
/*!40000 ALTER TABLE `Fiches_Tvaac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Tvaav`
--

DROP TABLE IF EXISTS `Fiches_Tvaav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Tvaav` (
  `code_tva` varchar(1) NOT NULL,
  `taux_tva` varchar(5) DEFAULT NULL,
  `cc_tva` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`code_tva`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Tvaav`
--

LOCK TABLES `Fiches_Tvaav` WRITE;
/*!40000 ALTER TABLE `Fiches_Tvaav` DISABLE KEYS */;
INSERT INTO `Fiches_Tvaav` VALUES ('1','2.10','445710'),('2','5.50','445720'),('3','19.60','445730');
/*!40000 ALTER TABLE `Fiches_Tvaav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fiches_Vendeurs`
--

DROP TABLE IF EXISTS `Fiches_Vendeurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fiches_Vendeurs` (
  `lind` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(2) DEFAULT NULL,
  `nom` varchar(35) DEFAULT NULL,
  `mdp` varchar(15) DEFAULT NULL,
  `admin` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`lind`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fiches_Vendeurs`
--

LOCK TABLES `Fiches_Vendeurs` WRITE;
/*!40000 ALTER TABLE `Fiches_Vendeurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `Fiches_Vendeurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Report`
--

DROP TABLE IF EXISTS `Report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Report` (
  `jour` varchar(2) DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `compte` varchar(8) NOT NULL,
  `collectif` int(11) DEFAULT NULL,
  `intitule` varchar(30) DEFAULT NULL,
  `dte` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datee` datetime DEFAULT NULL,
  `dateech` datetime DEFAULT NULL,
  `numcol` varchar(3) NOT NULL,
  `numdoc` varchar(10) DEFAULT NULL,
  `numlot` varchar(10) DEFAULT NULL,
  `libelle` varchar(30) DEFAULT NULL,
  `montantd` double DEFAULT NULL,
  `montantc` double DEFAULT NULL,
  `validee` tinyint(1) DEFAULT NULL,
  `provisoire` tinyint(1) DEFAULT NULL,
  `tresorerie` tinyint(1) DEFAULT NULL,
  `pointee` tinyint(1) DEFAULT NULL,
  `nrlv` int(11) DEFAULT NULL,
  `lettree` tinyint(1) DEFAULT NULL,
  `cloturee` tinyint(1) DEFAULT NULL,
  `relance` int(11) DEFAULT NULL,
  PRIMARY KEY (`numero`,`compte`,`dte`,`numcol`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Report`
--

LOCK TABLES `Report` WRITE;
/*!40000 ALTER TABLE `Report` DISABLE KEYS */;
/*!40000 ALTER TABLE `Report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Total`
--

DROP TABLE IF EXISTS `Total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Total` (
  `codeFam` char(5) NOT NULL,
  `designFam` char(30) DEFAULT NULL,
  `qte` decimal(12,2) DEFAULT NULL,
  `Brutht` decimal(12,2) DEFAULT NULL,
  `Remise` decimal(12,2) DEFAULT NULL,
  `totalht` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`codeFam`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Total`
--

LOCK TABLES `Total` WRITE;
/*!40000 ALTER TABLE `Total` DISABLE KEYS */;
/*!40000 ALTER TABLE `Total` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Totalisation`
--

DROP TABLE IF EXISTS `Totalisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Totalisation` (
  `compte` varchar(8) NOT NULL,
  `intitule` varchar(25) DEFAULT NULL,
  `totalht` varchar(25) DEFAULT NULL,
  `totaltva` varchar(25) DEFAULT NULL,
  `codetva` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`compte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Totalisation`
--

LOCK TABLES `Totalisation` WRITE;
/*!40000 ALTER TABLE `Totalisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Totalisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Totalisation01`
--

DROP TABLE IF EXISTS `Totalisation01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Totalisation01` (
  `compte` varchar(8) NOT NULL,
  `intitule` varchar(25) DEFAULT NULL,
  `totalht` varchar(25) DEFAULT NULL,
  `totaltva` varchar(25) DEFAULT NULL,
  `codetva` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`compte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Totalisation01`
--

LOCK TABLES `Totalisation01` WRITE;
/*!40000 ALTER TABLE `Totalisation01` DISABLE KEYS */;
/*!40000 ALTER TABLE `Totalisation01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tottva`
--

DROP TABLE IF EXISTS `Tottva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tottva` (
  `code` varchar(10) NOT NULL,
  `mtva` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tottva`
--

LOCK TABLES `Tottva` WRITE;
/*!40000 ALTER TABLE `Tottva` DISABLE KEYS */;
INSERT INTO `Tottva` VALUES ('20.00','10.4');
/*!40000 ALTER TABLE `Tottva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Virements`
--

DROP TABLE IF EXISTS `Virements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Virements` (
  `compte` char(8) NOT NULL,
  `intitule` char(35) DEFAULT NULL,
  `type` char(1) NOT NULL DEFAULT '',
  `montant` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`compte`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Virements`
--

LOCK TABLES `Virements` WRITE;
/*!40000 ALTER TABLE `Virements` DISABLE KEYS */;
/*!40000 ALTER TABLE `Virements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centralisation`
--

DROP TABLE IF EXISTS `centralisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `centralisation` (
  `numrub` varchar(5) NOT NULL,
  `intitrub` varchar(70) DEFAULT NULL,
  `type` varchar(1) DEFAULT NULL,
  `detail` varchar(1) DEFAULT NULL,
  `compte` varchar(8) NOT NULL,
  `intitcpt` varchar(50) DEFAULT NULL,
  `col1` varchar(12) DEFAULT NULL,
  `col2` varchar(12) DEFAULT NULL,
  `col3` varchar(12) DEFAULT NULL,
  `col4` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`numrub`,`compte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centralisation`
--

LOCK TABLES `centralisation` WRITE;
/*!40000 ALTER TABLE `centralisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `centralisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centralisations`
--

DROP TABLE IF EXISTS `centralisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `centralisations` (
  `cd_cent` varchar(8) NOT NULL,
  `intitule` varchar(25) DEFAULT NULL,
  `db_cent` double DEFAULT NULL,
  `crd_cent` double DEFAULT NULL,
  `njournal` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`cd_cent`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centralisations`
--

LOCK TABLES `centralisations` WRITE;
/*!40000 ALTER TABLE `centralisations` DISABLE KEYS */;
/*!40000 ALTER TABLE `centralisations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label_def`
--

DROP TABLE IF EXISTS `label_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label_def` (
  `label_no` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `manufacture` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `paper` varchar(1) DEFAULT NULL,
  `gap_top` double DEFAULT NULL,
  `gap_left` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `width` double DEFAULT NULL,
  `gap_v` double DEFAULT NULL,
  `gap_h` double DEFAULT NULL,
  `number_h` int(11) DEFAULT NULL,
  `number_v` int(11) DEFAULT NULL,
  `paper_type` varchar(30) DEFAULT NULL,
  `compatibility` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`label_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label_def`
--

LOCK TABLES `label_def` WRITE;
/*!40000 ALTER TABLE `label_def` DISABLE KEYS */;
/*!40000 ALTER TABLE `label_def` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-27 19:01:17
